-- ═══════════════════════════════════════════════════════════════════════════
-- StreamAnalytics Pro — Schema ClickHouse pour metriques streaming temps reel
-- Concu pour de gros volumes (millions d'evenements/seconde)
-- ═══════════════════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS streamanalytics;

-- ─────────────────────────────────────────────────────────────────────────────
-- Table brute : chaque ligne = une mesure remontee par un agent
-- Partitionnee par jour, triee pour des requetes rapides par org/cdn/temps
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS streamanalytics.metrics_raw
(
    event_time      DateTime64(3)          CODEC(DoubleDelta, ZSTD(1)),
    org_id          LowCardinality(String),
    session_id      String,
    cdn             LowCardinality(String),
    region          LowCardinality(String),
    device          LowCardinality(String),

    -- Metriques QoE
    rebuffer_rate   Float32                CODEC(Gorilla, ZSTD(1)),
    bitrate_mbps    Float32                CODEC(Gorilla, ZSTD(1)),
    startup_time_s  Float32                CODEC(Gorilla, ZSTD(1)),
    latency_p95_s   Float32                CODEC(Gorilla, ZSTD(1)),
    error_rate      Float32                CODEC(Gorilla, ZSTD(1)),
    cdn_health      Float32                CODEC(Gorilla, ZSTD(1)),
    viewers         UInt32                 CODEC(T64, ZSTD(1))
)
ENGINE = MergeTree
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (org_id, cdn, event_time)
TTL toDateTime(event_time) + INTERVAL 90 DAY    -- purge auto apres 90 jours
SETTINGS index_granularity = 8192;

-- ─────────────────────────────────────────────────────────────────────────────
-- Vue materialisee : agregats par minute (pour les dashboards rapides)
-- ClickHouse maintient cette table a jour automatiquement a l'insertion
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS streamanalytics.metrics_1min
(
    minute          DateTime               CODEC(DoubleDelta, ZSTD(1)),
    org_id          LowCardinality(String),
    cdn             LowCardinality(String),

    rebuffer_avg    AggregateFunction(avg, Float32),
    bitrate_avg     AggregateFunction(avg, Float32),
    startup_avg     AggregateFunction(avg, Float32),
    latency_p95     AggregateFunction(quantile(0.95), Float32),
    error_avg       AggregateFunction(avg, Float32),
    cdn_health_avg  AggregateFunction(avg, Float32),
    viewers_max     AggregateFunction(max, UInt32),
    samples         AggregateFunction(count, UInt8)
)
ENGINE = AggregatingMergeTree
PARTITION BY toYYYYMMDD(minute)
ORDER BY (org_id, cdn, minute)
TTL minute + INTERVAL 1 YEAR;

CREATE MATERIALIZED VIEW IF NOT EXISTS streamanalytics.metrics_1min_mv
TO streamanalytics.metrics_1min
AS
SELECT
    toStartOfMinute(event_time)              AS minute,
    org_id,
    cdn,
    avgState(rebuffer_rate)                  AS rebuffer_avg,
    avgState(bitrate_mbps)                   AS bitrate_avg,
    avgState(startup_time_s)                 AS startup_avg,
    quantileState(0.95)(latency_p95_s)       AS latency_p95,
    avgState(error_rate)                     AS error_avg,
    avgState(cdn_health)                     AS cdn_health_avg,
    maxState(viewers)                        AS viewers_max,
    countState(toUInt8(1))                   AS samples
FROM streamanalytics.metrics_raw
GROUP BY minute, org_id, cdn;
