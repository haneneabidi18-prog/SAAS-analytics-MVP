#!/usr/bin/env python3
"""
StreamAnalytics Pro — Agent de collecte de metriques

Deploye chez le client (ISP), cet agent collecte les metriques streaming et
les envoie par batch vers ClickHouse. Concu pour tenir la charge : buffer
local, envoi par lots, retry avec backoff, et arret propre.

Deux sources possibles :
  - SIMULATE : genere des metriques realistes (demo / tests de charge)
  - HTTP     : interroge un endpoint qui expose des metriques (sonde, player API)

Configuration via variables d'environnement (voir .env.example).
"""

import os
import sys
import time
import json
import signal
import random
import logging
from datetime import datetime
from collections import deque

import clickhouse_connect

# ── Configuration ─────────────────────────────────────────────────────────────
CH_HOST      = os.getenv("CLICKHOUSE_HOST", "localhost")
CH_PORT      = int(os.getenv("CLICKHOUSE_PORT", "8123"))
CH_USER      = os.getenv("CLICKHOUSE_USER", "default")
CH_PASSWORD  = os.getenv("CLICKHOUSE_PASSWORD", "")
CH_DATABASE  = os.getenv("CLICKHOUSE_DATABASE", "streamanalytics")

ORG_ID       = os.getenv("ORG_ID", "demo-org")
SOURCE_MODE  = os.getenv("SOURCE_MODE", "SIMULATE").upper()   # SIMULATE | HTTP
HTTP_ENDPOINT = os.getenv("HTTP_ENDPOINT", "")

BATCH_SIZE   = int(os.getenv("BATCH_SIZE", "500"))
FLUSH_SECONDS = float(os.getenv("FLUSH_SECONDS", "5"))
SAMPLE_HZ    = float(os.getenv("SAMPLE_HZ", "50"))   # mesures generees/seconde en mode SIMULATE

CDNS    = os.getenv("CDNS", "CDN-EU1,CDN-FR2,CDN-US1").split(",")
REGIONS = os.getenv("REGIONS", "EU-West,EU-Central,US-East").split(",")
DEVICES = os.getenv("DEVICES", "web,mobile,tv,console").split(",")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("agent")

# ── Etat global pour arret propre ─────────────────────────────────────────────
_running = True

def _handle_signal(signum, frame):
    global _running
    log.info("Signal %s recu — arret en cours...", signum)
    _running = False

signal.signal(signal.SIGINT,  _handle_signal)
signal.signal(signal.SIGTERM, _handle_signal)


# ── Connexion ClickHouse ──────────────────────────────────────────────────────
def connect_clickhouse():
    """Connexion avec retry exponentiel (ClickHouse peut demarrer apres l'agent)."""
    delay = 1
    while _running:
        try:
            client = clickhouse_connect.get_client(
                host=CH_HOST, port=CH_PORT,
                username=CH_USER, password=CH_PASSWORD,
                database=CH_DATABASE,
            )
            client.query("SELECT 1")
            log.info("Connecte a ClickHouse sur %s:%s", CH_HOST, CH_PORT)
            return client
        except Exception as e:
            log.warning("ClickHouse indisponible (%s). Nouvelle tentative dans %ss", e, delay)
            time.sleep(delay)
            delay = min(delay * 2, 30)
    return None


# ── Generation de metriques simulees ──────────────────────────────────────────
# Etat persistant par CDN pour des series temporelles realistes (pas du bruit pur)
_cdn_state = {
    cdn: {
        "health":   random.uniform(97, 99.5),
        "rebuffer": random.uniform(0.3, 0.8),
        "viewers":  random.randint(5000, 40000),
    }
    for cdn in CDNS
}

def _drift(value, lo, hi, step):
    """Fait deriver une valeur de maniere realiste (marche aleatoire bornee)."""
    value += random.uniform(-step, step)
    return max(lo, min(hi, value))

def simulate_one() -> dict:
    """Genere une mesure realiste avec correlations entre metriques."""
    cdn   = random.choice(CDNS)
    state = _cdn_state[cdn]

    # Derive lente de l'etat du CDN
    state["health"]   = _drift(state["health"],   88.0, 99.9, 0.15)
    state["rebuffer"] = _drift(state["rebuffer"],  0.1,  4.0, 0.08)
    state["viewers"]  = int(_drift(state["viewers"], 1000, 80000, 400))

    # Correlations : un CDN degrade -> plus de rebuffering, moins de bitrate
    health_factor = (100 - state["health"]) / 12.0
    rebuffer = round(state["rebuffer"] + health_factor * random.uniform(0.5, 1.2), 3)
    bitrate  = round(_drift(5.0 - health_factor, 1.5, 8.0, 0.3), 2)
    startup  = round(1.5 + health_factor * random.uniform(0.3, 1.0), 2)
    latency  = round(2.0 + health_factor * random.uniform(0.4, 1.5), 2)
    error    = round(max(0.0, health_factor * random.uniform(0.1, 0.5)), 3)

    return {
        "event_time":     datetime.now(),
        "org_id":         ORG_ID,
        "session_id":     f"sess-{random.randint(1, 999999):06d}",
        "cdn":            cdn,
        "region":         random.choice(REGIONS),
        "device":         random.choice(DEVICES),
        "rebuffer_rate":  rebuffer,
        "bitrate_mbps":   bitrate,
        "startup_time_s": startup,
        "latency_p95_s":  latency,
        "error_rate":     error,
        "cdn_health":     round(state["health"], 2),
        "viewers":        state["viewers"],
    }


# ── Source HTTP (metriques reelles) ───────────────────────────────────────────
def fetch_http() -> list[dict]:
    """
    Interroge un endpoint qui retourne des metriques au format JSON.
    Format attendu : liste d'objets avec les memes cles que simulate_one().
    Adapte le parsing a la structure reelle de la sonde/player du client.
    """
    import urllib.request
    rows = []
    try:
        with urllib.request.urlopen(HTTP_ENDPOINT, timeout=5) as resp:
            payload = json.loads(resp.read().decode())
        items = payload if isinstance(payload, list) else payload.get("metrics", [])
        for item in items:
            rows.append({
                "event_time":     datetime.now(),
                "org_id":         ORG_ID,
                "session_id":     str(item.get("session_id", "")),
                "cdn":            str(item.get("cdn", "unknown")),
                "region":         str(item.get("region", "unknown")),
                "device":         str(item.get("device", "unknown")),
                "rebuffer_rate":  float(item.get("rebuffer_rate", 0)),
                "bitrate_mbps":   float(item.get("bitrate_mbps", 0)),
                "startup_time_s": float(item.get("startup_time_s", 0)),
                "latency_p95_s":  float(item.get("latency_p95_s", 0)),
                "error_rate":     float(item.get("error_rate", 0)),
                "cdn_health":     float(item.get("cdn_health", 100)),
                "viewers":        int(item.get("viewers", 0)),
            })
    except Exception as e:
        log.warning("Echec fetch HTTP : %s", e)
    return rows


# ── Insertion par batch ───────────────────────────────────────────────────────
COLUMNS = [
    "event_time", "org_id", "session_id", "cdn", "region", "device",
    "rebuffer_rate", "bitrate_mbps", "startup_time_s", "latency_p95_s",
    "error_rate", "cdn_health", "viewers",
]

def flush(client, buffer: deque) -> int:
    """Envoie le buffer vers ClickHouse. Retourne le nombre de lignes envoyees."""
    if not buffer:
        return 0
    rows = [[row[c] for c in COLUMNS] for row in buffer]
    delay = 1
    while _running or buffer:   # on tente meme pendant l'arret pour ne rien perdre
        try:
            client.insert("metrics_raw", rows, column_names=COLUMNS)
            n = len(rows)
            buffer.clear()
            return n
        except Exception as e:
            log.warning("Echec insertion (%s). Retry dans %ss", e, delay)
            time.sleep(delay)
            delay = min(delay * 2, 30)
    return 0


# ── Boucle principale ─────────────────────────────────────────────────────────
def main():
    log.info("Demarrage agent | org=%s | mode=%s | batch=%d | flush=%.1fs",
             ORG_ID, SOURCE_MODE, BATCH_SIZE, FLUSH_SECONDS)

    client = connect_clickhouse()
    if client is None:
        log.error("Impossible de se connecter a ClickHouse. Arret.")
        sys.exit(1)

    buffer = deque()
    last_flush = time.time()
    total_sent = 0
    sample_interval = 1.0 / SAMPLE_HZ if SAMPLE_HZ > 0 else 0.02

    while _running:
        # ── Collecte ──
        if SOURCE_MODE == "HTTP" and HTTP_ENDPOINT:
            buffer.extend(fetch_http())
            time.sleep(1)   # poll HTTP toutes les secondes
        else:
            buffer.append(simulate_one())
            time.sleep(sample_interval)

        # ── Flush si batch plein ou delai ecoule ──
        now = time.time()
        if len(buffer) >= BATCH_SIZE or (now - last_flush) >= FLUSH_SECONDS:
            sent = flush(client, buffer)
            if sent:
                total_sent += sent
                log.info("Envoye %d mesures (total: %d)", sent, total_sent)
            last_flush = now

    # ── Arret propre : on vide le buffer restant ──
    log.info("Arret demande — flush final de %d mesures bufferisees", len(buffer))
    sent = flush(client, buffer)
    total_sent += sent
    log.info("Agent arrete proprement. Total envoye : %d mesures", total_sent)


if __name__ == "__main__":
    main()
