# StreamAnalytics Pro — Pipeline de collecte temps reel

Systeme de collecte et stockage de metriques streaming a haut volume :
**Agent de collecte** → **ClickHouse** (base time-series) → lu par ton app Streamlit.

```
┌─────────────────┐     ┌──────────────┐     ┌─────────────────┐
│  Agent collecte │ ──▶ │  ClickHouse  │ ──▶ │  App Streamlit  │
│  (chez le client)│     │ (time-series)│     │ (visualisation) │
└─────────────────┘     └──────────────┘     └─────────────────┘
```

---

## Contenu

| Fichier | Role |
|---|---|
| `agent/agent.py` | Agent de collecte : genere ou collecte les metriques, envoie par batch |
| `agent/Dockerfile` | Image Docker de l'agent |
| `clickhouse/init/01_schema.sql` | Schema ClickHouse (tables + vue agregee 1min + TTL) |
| `docker-compose.yml` | Orchestration ClickHouse + agent |
| `api/clickhouse_reader.py` | Module a copier dans `utils/` de ton app Streamlit pour lire les donnees |
| `.env.example` | Variables de configuration |

---

## Demarrage rapide (test local en 3 commandes)

Prerequis : Docker + Docker Compose installes.

```bash
# 1. Copier la config et choisir un mot de passe
cp .env.example .env
# (edite .env : change CLICKHOUSE_PASSWORD)

# 2. Lancer ClickHouse + l'agent (mode SIMULATE par defaut)
docker compose up -d

# 3. Verifier que les donnees arrivent
docker exec sa-clickhouse clickhouse-client --query \
  "SELECT count(), uniq(cdn) FROM streamanalytics.metrics_raw"
```

Au bout de quelques secondes, tu devrais voir le compteur grimper. L'agent
genere ~50 mesures/seconde par defaut (reglable via `SAMPLE_HZ`).

Pour suivre les logs de l'agent :
```bash
docker compose logs -f agent
```

---

## Passer en mode "metriques reelles"

En production chez un client, tu remplaces le mode SIMULATE par une vraie source.

Dans `.env` :
```bash
SOURCE_MODE=HTTP
HTTP_ENDPOINT=http://sonde-du-client.local:9090/metrics
ORG_ID=orange-telecom        # identifiant unique du client
```

L'endpoint doit retourner du JSON (liste d'objets). Adapte la fonction
`fetch_http()` dans `agent.py` au format reel de la sonde / API player du client.

> En pratique, chaque client a une source differente (logs CDN, API de son
> player, sonde reseau...). L'agent est concu pour qu'on n'adapte qu'une seule
> fonction (`fetch_http`) par type de source.

---

## Brancher ton app Streamlit sur les donnees reelles

1. Copie `api/clickhouse_reader.py` dans `utils/` de ton app StreamAnalytics.

2. Ajoute `clickhouse-connect>=0.7.0` a ton `requirements.txt`.

3. Dans les secrets Streamlit Cloud, ajoute :
   ```toml
   CLICKHOUSE_HOST = "ton-serveur-clickhouse.com"
   CLICKHOUSE_PORT = 8123
   CLICKHOUSE_USER = "default"
   CLICKHOUSE_PASSWORD = "..."
   CLICKHOUSE_DATABASE = "streamanalytics"
   ```

4. Dans `utils/data.py`, modifie `get_live_metrics()` pour tenter d'abord
   les donnees reelles, puis retomber sur la simulation :

   ```python
   def get_live_metrics():
       try:
           from utils.clickhouse_reader import get_live_metrics_real
           import streamlit as st
           org = st.session_state.get("org")
           org_id = org["id"] if org else "demo-org"
           real = get_live_metrics_real(org_id)
           if real:
               return real
       except Exception:
           pass
       # ... fallback : ta simulation existante ...
   ```

Ainsi la demo (sans ClickHouse) continue de marcher avec la simulation, et la
production (avec ClickHouse) affiche les vraies donnees — sans toucher aux pages.

---

## Architecture du stockage

**Table `metrics_raw`** : chaque mesure brute. Partitionnee par jour, compressee
(codecs Gorilla/ZSTD adaptes aux series temporelles), purgee automatiquement
apres 90 jours (TTL).

**Vue `metrics_1min`** : agregats par minute maintenus automatiquement par
ClickHouse a chaque insertion. C'est ce que tes dashboards interrogent pour etre
rapides meme sur des milliards de lignes brutes — conservee 1 an.

Cette separation (brut court terme + agrege long terme) est la cle pour tenir le
volume d'un gros ISP sans exploser le cout de stockage.

---

## Mise a l'echelle

Pour un tres gros ISP, l'ordre de montee en charge recommande :

1. **Un agent par source** (plusieurs agents peuvent ecrire dans le meme ClickHouse).
2. **ClickHouse sur un serveur dedie** (CPU + SSD rapides) plutot qu'en conteneur local.
3. Si le debit depasse ce qu'un ClickHouse encaisse en direct, **intercaler Kafka**
   entre les agents et ClickHouse (buffer de pics). Le `agent.py` ecrirait alors
   dans Kafka, et un consumer ClickHouse (table engine Kafka) absorberait le flux.

Cette derniere etape n'est utile qu'a tres grande echelle — commence simple.
